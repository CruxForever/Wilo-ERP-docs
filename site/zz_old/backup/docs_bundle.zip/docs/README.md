# Wilo‑ERP — Mini ERP (НСИ, Бюджет, Калькуляции)

## Быстрый старт
1) Запустить `app_streamlit.py`.  
2) Перейти в **НСИ** → вкладка **Справочники**.  
3) Подготовить БД и загрузить MFCPRIM/CCG.  
4) Вкладка **Правила**: импорт `detail_rules`/`fallback_rules`.  
5) Вкладка **Просмотр деревьев** и **Проверка данных** для контроля качества.

## Где что
- `ui/ui_nsi_references.py` — страница НСИ (вкладки).
- `loaders/load_cost_structures.py` — MFCPRIM (elements) parser + upsert.
- `loaders/ccg_wru_loader.py` — CCG WRU (cost centers) parser + upsert.
- `loaders/rules_loader.py` — таблица правил, импорт из Excel, CRUD.
- `db/connection.py` — `normalize_db_path`, обвязка SQLite.

## Зачем docs/
- Перенос контекста между чатами и ZIP‑релизами.
- Консистентное онбординг‑описание и runbook.
